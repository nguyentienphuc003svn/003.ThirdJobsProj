--------------------------------------------------------
--  File created - Tuesday-April-14-2015   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table T_USER
--------------------------------------------------------

  CREATE TABLE "FEELVIEW"."T_USER" 
  (	
    "USER_ID" VARCHAR2(10 BYTE), 
	"CATEFORY_ID" VARCHAR2(10 BYTE), 
	"FIRST_NAME" VARCHAR2(100 BYTE), 
	"LAST_NAME" VARCHAR2(100 BYTE), 
	"DOB" VARCHAR2(100 BYTE), 
	"ADDRESS" VARCHAR2(100 BYTE), 
	"TEL" VARCHAR2(100 BYTE), 
	"TYPE" VARCHAR2(100 BYTE), 
	"SIGNATURE_FILE" VARCHAR2(100 BYTE), 
	"CATEFORY_DEFAULT" VARCHAR2(100 BYTE)
   ) 
  
SET DEFINE OFF;
Insert into FEELVIEW.T_USER (USER_ID,CATEFORY_ID,FIRST_NAME,LAST_NAME,DOB,ADDRESS,TEL,TYPE,SIGNATURE_FILE,CATEFORY_DEFAULT) values ('0001','0001','AAA','BBB','19981110','USA','11111111','0','www.aaa.com','0001');
Insert into FEELVIEW.T_USER (USER_ID,CATEFORY_ID,FIRST_NAME,LAST_NAME,DOB,ADDRESS,TEL,TYPE,SIGNATURE_FILE,CATEFORY_DEFAULT) values ('0002','0002','CCC','DDD','19981109','VNM','22222222','1','www.ccc.com','0002');
Insert into FEELVIEW.T_USER (USER_ID,CATEFORY_ID,FIRST_NAME,LAST_NAME,DOB,ADDRESS,TEL,TYPE,SIGNATURE_FILE,CATEFORY_DEFAULT) values ('0003','0003','EEE','FFF','19981008','CHN','33333333','2','www.eee.com','0003');
