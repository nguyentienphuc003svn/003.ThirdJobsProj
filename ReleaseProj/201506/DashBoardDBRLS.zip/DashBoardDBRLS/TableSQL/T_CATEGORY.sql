--------------------------------------------------------
--  File created - Tuesday-April-14-2015   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table T_CATEGORY
--------------------------------------------------------

  CREATE TABLE "FEELVIEW"."T_CATEGORY" 
  (	
    "CATEFORY_ID" VARCHAR2(10 BYTE), 
	"NAME" VARCHAR2(100 BYTE), 
	"PERMISSION" VARCHAR2(100 BYTE)
   ) 

SET DEFINE OFF;
Insert into FEELVIEW.T_CATEGORY (CATEFORY_ID,NAME,PERMISSION) values ('0001','Regular','Regular');
Insert into FEELVIEW.T_CATEGORY (CATEFORY_ID,NAME,PERMISSION) values ('0002','Advanced','Advanced');
Insert into FEELVIEW.T_CATEGORY (CATEFORY_ID,NAME,PERMISSION) values ('0003','Admin','Admin');
