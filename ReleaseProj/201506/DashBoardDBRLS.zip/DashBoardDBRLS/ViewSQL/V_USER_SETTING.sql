--------------------------------------------------------
--  File created - Tuesday-April-14-2015   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for View V_USER_SETTING
--------------------------------------------------------

CREATE OR REPLACE FORCE VIEW "FEELVIEW"."V_USER_SETTING" ("USER_ID", "CATEFORY_ID", "FIRST_NAME", "LAST_NAME", "DOB", "ADDRESS", "TEL", "TYPE", "SIGNATURE_FILE", "CATEFORY_DEFAULT", "NAME", "PERMISSION") AS 
select
t_user.USER_ID,
t_user.CATEFORY_ID,
t_user.FIRST_NAME,
t_user.LAST_NAME,
t_user.DOB,
t_user.ADDRESS,
t_user.TEL,
t_user.TYPE,
t_user.SIGNATURE_FILE,
t_user.CATEFORY_DEFAULT,

t_category.NAME,
t_category.PERMISSION

from t_user, t_category
where t_user.CATEFORY_ID = t_category.CATEFORY_ID;

SET DEFINE OFF;
Insert into FEELVIEW.V_USER_SETTING (USER_ID,CATEFORY_ID,FIRST_NAME,LAST_NAME,DOB,ADDRESS,TEL,TYPE,SIGNATURE_FILE,CATEFORY_DEFAULT,NAME,PERMISSION) values ('0001','0001','AAA','BBB','19981110','USA','11111111','0','www.aaa.com','0001','Regular','Regular');
Insert into FEELVIEW.V_USER_SETTING (USER_ID,CATEFORY_ID,FIRST_NAME,LAST_NAME,DOB,ADDRESS,TEL,TYPE,SIGNATURE_FILE,CATEFORY_DEFAULT,NAME,PERMISSION) values ('0002','0002','CCC','DDD','19981109','VNM','22222222','1','www.ccc.com','0002','Advanced','Advanced');
Insert into FEELVIEW.V_USER_SETTING (USER_ID,CATEFORY_ID,FIRST_NAME,LAST_NAME,DOB,ADDRESS,TEL,TYPE,SIGNATURE_FILE,CATEFORY_DEFAULT,NAME,PERMISSION) values ('0003','0003','EEE','FFF','19981008','CHN','33333333','2','www.eee.com','0003','Admin','Admin');
