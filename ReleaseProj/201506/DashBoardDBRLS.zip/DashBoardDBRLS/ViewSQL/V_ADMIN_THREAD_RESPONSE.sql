--------------------------------------------------------
--  File created - Tuesday-April-14-2015   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for View V_ADMIN_THREAD_RESPONSE
--------------------------------------------------------

CREATE OR REPLACE FORCE VIEW "FEELVIEW"."V_ADMIN_THREAD_RESPONSE" ("USER_ID", "FIRST_NAME", "LAST_NAME", "THREAD_ID", "TITLE", "CONTENT", "RANK", "STATUS", "THREAD_DATE", "THREAD_TIME", "CATEFORY_ID", "RESPONSE_ID", "RES_CONTENT", "RES_STATUS", "USER_IP", "RES_DATE", "RES_TIME") AS 
select
t_user.USER_ID,
t_user.FIRST_NAME,
t_user.LAST_NAME,

t_thread.THREAD_ID,
t_thread.TITLE,
t_thread.CONTENT,
t_thread.RANK,
t_thread.STATUS,
t_thread.THREAD_DATE,
t_thread.THREAD_TIME,
t_thread.CATEFORY_ID,

t_response.RESPONSE_ID,
t_response.CONTENT as RES_CONTENT,
t_response.STATUS as RES_STATUS,
t_response.USER_IP,
t_response.RES_DATE,
t_response.RES_TIME

from t_user, t_thread, t_response
Where t_user.USER_ID = t_thread.USER_ID 
      and t_thread.THREAD_ID = t_response.THREAD_ID
      and t_user.CATEFORY_ID = '0001'
      and (t_thread.STATUS = 'hidden' and t_response.STATUS = 'hidden');

SET DEFINE OFF;
Insert into FEELVIEW.V_ADMIN_THREAD_RESPONSE (USER_ID,FIRST_NAME,LAST_NAME,THREAD_ID,TITLE,CONTENT,RANK,STATUS,THREAD_DATE,THREAD_TIME,CATEFORY_ID,RESPONSE_ID,RES_CONTENT,RES_STATUS,USER_IP,RES_DATE,RES_TIME) values ('0001','AAA','BBB','00000002','Math2','Math2','2','hidden','20151111','121212000000','0001','00000004','DDD','hidden','192.168.11.1','20151111','1121212000000');
