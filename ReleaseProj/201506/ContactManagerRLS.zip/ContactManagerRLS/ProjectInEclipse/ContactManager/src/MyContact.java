import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Scanner;


public class MyContact {

	public static ArrayList<String> Fname = new ArrayList<String>();
	public static ArrayList<String> Lname = new ArrayList<String>(0);
	public static ArrayList<String> Extension = new ArrayList<String>();

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		MyContact mc = new MyContact();
		mc.ContactInit();

		String myChoice = mc.getChoice();
		//System.out.println("Choice + [" + myChoice + "]");

		while (!myChoice.equalsIgnoreCase("9"))
		{
			if (myChoice.equals("1")) mc.addContact();
			if (myChoice.equals("2")) mc.changeContact();
			if (myChoice.equals("3")) mc.deleteContact();
			if (myChoice.equals("4")) mc.listContact();
			if (myChoice.equals("5")) mc.saveContact();

			System.out.println("\n\n");
			myChoice = mc.getChoice();
		}

		//Save
		mc.saveContact();
		System.out.println("\nEnd of Contact Manager");

	}

	public void ContactInit()
	{
		try
		{
			// Open file
			//String current = new java.io.File( "." ).getCanonicalPath();
			//System.out.println("Current dir:"+current);

			FileInputStream fstream = new FileInputStream("Contacts.txt");
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF8"));

			String strLine;

			//Read File Line By Line
			int index = 0;
			while ((strLine = br.readLine()) != null) 
			{
				if (strLine.split(" ",-1).length <= 0) continue;

				//System.out.println("Processing Line + [" + strLine + "]");
				if (strLine.split(" ",-1).length > 1)
				{
					String fname = strLine.split(" ",-1)[0];
					String lname = strLine.split(" ",-1)[1];
					String extension = strLine.split(" ",-1)[2];
					//System.out.println("fname + [" + fname + "]");

					MyContact.Fname.add(fname);
					MyContact.Lname.add(lname);
					MyContact.Extension.add(extension);
					index++;
				}
			}

			//Close the input stream			
			in.close();
		}
		catch (Exception e){
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace();
		}
	}

	//Input Prompt
	public String getChoice()
	{
		System.out.println("Welcome to Contact Manager");
		System.out.println("--------------------");
		this.showFiveContact();

		System.out.println("\nContact Manager Menu");
		System.out.println("--------------------");
		System.out.println("1 - Add contact");
		System.out.println("2 - Change contact");
		System.out.println("3 � Delete contact");
		System.out.println("4 � List contacts");
		System.out.println("5 � Save contacts");
		System.out.println("9 - Exit");
		System.out.println("\nEnter an option:");

		Scanner scan = new Scanner(System.in);
		String CustChoice = scan.nextLine();		
		while (CustChoice.matches("[0-9]+") == false) 
		{	
			System.out.println("\nEnter a VALID option:");
			CustChoice = scan.nextLine();
		}
		while (Integer.parseInt(CustChoice) != 1 && Integer.parseInt(CustChoice) != 2 && Integer.parseInt(CustChoice) != 3 && Integer.parseInt(CustChoice) != 4 && Integer.parseInt(CustChoice) != 5 && Integer.parseInt(CustChoice) != 9)
		{	
			System.out.println("\nEnter a VALID option:");
			CustChoice = scan.nextLine();
		}

		return CustChoice;
	}

	public void addContact()
	{
		//Fname
		System.out.println("Please enter the First Name");
		Scanner scan = new Scanner(System.in);
		String fnameScan = scan.nextLine();		
		while (fnameScan.length()<=0) 
		{	
			System.out.println("Please enter the VALID First Name");
			fnameScan = scan.nextLine();
		}
		MyContact.Fname.add(fnameScan);

		//Lname
		System.out.println("Please enter the Last Name");
		String lnameScan = scan.nextLine();		
		while (lnameScan.length()<=0) 
		{	
			System.out.println("Please enter the VALID Last Name");
			lnameScan = scan.nextLine();
		}
		MyContact.Lname.add(lnameScan);

		//Extension
		System.out.println("Please enter the Extension");
		String extensionScan = scan.nextLine();		
		while (extensionScan.length()<=0) 
		{	
			System.out.println("Please enter the VALID Extension");
			extensionScan = scan.nextLine();
		}
		while (extensionScan.matches("[0-9]+") == false) 
		{	
			System.out.println("Please enter the VALID Extension");
			extensionScan = scan.nextLine();
		}		
		MyContact.Extension.add(extensionScan);
	}

	public void changeContact()
	{
		//getPosition
		System.out.println("Please enter the position need to change from 0 to " + (MyContact.Fname.size()-1));
		Scanner scan = new Scanner(System.in);
		String positionScan = scan.nextLine();
		while (positionScan.matches("[0-9]+") == false) 
		{	
			System.out.println("\nEnter a VALID position:");
			positionScan = scan.nextLine();
		}
		while (Integer.parseInt(positionScan) <=0 || Integer.parseInt(positionScan) >= MyContact.Fname.size())
		{	
			System.out.println("\nEnter a VALID position:");
			positionScan = scan.nextLine();
		}

		//Fname Again
		System.out.println("Please enter the New First Name");
		String fnameScan = scan.nextLine();		
		while (fnameScan.length()<=0) 
		{	
			System.out.println("Please enter the VALID First Name");
			fnameScan = scan.nextLine();
		}
		MyContact.Fname.remove(Integer.parseInt(positionScan));
		MyContact.Fname.add(Integer.parseInt(positionScan), fnameScan);

		//Fname
		System.out.println("Please enter the NEW Last Name");
		String lnameScan = scan.nextLine();		
		while (lnameScan.length()<=0) 
		{	
			System.out.println("Please enter the VALID Last Name");
			lnameScan = scan.nextLine();
		}
		MyContact.Lname.remove(Integer.parseInt(positionScan));
		MyContact.Lname.add(Integer.parseInt(positionScan), lnameScan);

		//Extension
		System.out.println("Please enter the NEW Extension");
		String extensionScan = scan.nextLine();		
		while (extensionScan.length()<=0) 
		{	
			System.out.println("Please enter the VALID Extension");
			extensionScan = scan.nextLine();
		}
		while (extensionScan.matches("[0-9]+") == false) 
		{	
			System.out.println("Please enter the VALID Extension");
			extensionScan = scan.nextLine();
		}
		MyContact.Extension.remove(Integer.parseInt(positionScan));
		MyContact.Extension.add(Integer.parseInt(positionScan), extensionScan);
	}

	public void deleteContact()
	{
		//getPosition
		System.out.println("Please enter the position need to DELETE from 0 to " + (MyContact.Fname.size()-1));
		Scanner scan = new Scanner(System.in);
		String positionScan = scan.nextLine();
		while (positionScan.matches("[0-9]+") == false) 
		{	
			System.out.println("\nEnter a VALID position:");
			positionScan = scan.nextLine();
		}
		while (Integer.parseInt(positionScan) <=0 || Integer.parseInt(positionScan) >= MyContact.Fname.size())
		{	
			System.out.println("\nEnter a VALID position:");
			positionScan = scan.nextLine();
		}
		MyContact.Fname.remove(Integer.parseInt(positionScan));
		MyContact.Lname.remove(Integer.parseInt(positionScan));
		MyContact.Extension.remove(Integer.parseInt(positionScan));
	}

	public void listContact()
	{
		System.out.println("First Name   Last Name   Extension");			
		for (int i=0; i<MyContact.Fname.size(); i++)
		{
			System.out.println(MyContact.Fname.get(i).trim() + " " + MyContact.Lname.get(i).trim() + " " + MyContact.Extension.get(i).trim());
		}
	}

	public void saveContact()
	{
		try {

//			FileInputStream fstream = new FileInputStream("Contacts.txt");
//			DataInputStream in = new DataInputStream(fstream);
//			BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF8"));

			File file = new File("Contacts.txt");

			if (!file.exists()) {
				file.createNewFile();
			}

			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			
			for (int i=0; i<MyContact.Fname.size(); i++)
			{
				String content = MyContact.Fname.get(i) + " " + MyContact.Lname.get(i) + " " + MyContact.Extension.get(i) +"\n";
				bw.write(content);

			}
			bw.close();
			System.out.println("Total " + MyContact.Fname.size() + " contact(s) are written to file Contacts.txt");

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void showFiveContact()
	{
		for (int i=0; i<MyContact.Fname.size(); i++)
		{
			System.out.println(MyContact.Fname.get(i) + " " + MyContact.Lname.get(i) + " " + MyContact.Extension.get(i));
		}
	}

	public void showArray(Object[] showArray)
	{
		for (int i=0; i<showArray.length; i++)
		{
			System.out.println("Value at [" + (i+1) + "] is [" + String.valueOf(showArray[i]) + "]");
		}
	}



}
