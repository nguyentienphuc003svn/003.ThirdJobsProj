import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Scanner;


public class TableSorter {

	public static String[] chapter;
	public static String[] title;
	public static String[] page;

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		TableSorter ts = new TableSorter();
		ts.ChapterInit();
		ts.sortContents(chapter);
		//ts.showArray(chapter);
		//ts.showArray(title);
		//ts.showArray(page);
		
		ts.displayTable(chapter, title, page);

	}

	public void ChapterInit()
	{
		try
		{
			// Open file
			//String current = new java.io.File( "." ).getCanonicalPath();
			//System.out.println("Current dir:"+current);

			FileInputStream fstream = new FileInputStream("toc.txt");
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF8"));

			String strLine;

			//Read File Line By Line
			int index = 0;
			while ((strLine = br.readLine()) != null) 
			{
				if (strLine.split(";",-1).length <= 0) continue;

				//System.out.println("Processing Line + [" + strLine + "]");
				if (strLine.split(";",-1).length == 1) 
				{	
					chapter = new String[Integer.parseInt(strLine.split(";",-1)[0])];
					title = new String[Integer.parseInt(strLine.split(";",-1)[0])];
					page = new String[Integer.parseInt(strLine.split(";",-1)[0])];
				}

				if (strLine.split(";",-1).length > 1)
				{
					String chapterSplit = strLine.split(";",-1)[0];
					String titleSplit = strLine.split(";",-1)[1];
					String pageSplit = strLine.split(";",-1)[2];
					//System.out.println("CityName + [" + cityName + "]");

					TableSorter.chapter[index] = chapterSplit;
					TableSorter.title[index] = titleSplit;
					TableSorter.page[index] = pageSplit;
					index++;
				}
			}

			//Close the input stream			
			in.close();
		}
		catch (Exception e){
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace();
		}
	}

	public void sortContents(String[] uChapter)
	{
		for (int i=0; i<TableSorter.chapter.length; i++)
		{		
			for (int j=i+1; j<TableSorter.chapter.length; j++)				
			{
				if (Integer.parseInt(TableSorter.chapter[j]) < Integer.parseInt(TableSorter.chapter[i]))
				{
					//Sort for chapter
					String tempChapter = TableSorter.chapter[i];
					TableSorter.chapter[i] = TableSorter.chapter[j];
					TableSorter.chapter[j] = tempChapter;
					
					//Sort for Title
					String tempTitle = TableSorter.title[i];
					TableSorter.title[i] = TableSorter.title[j];
					TableSorter.title[j] = tempTitle;
					
					//Sort for Page
					String tempPage = TableSorter.page[i];
					TableSorter.page[i] = TableSorter.page[j];
					TableSorter.page[j] = tempPage;
				}
			}
		}
	}

	public void showArray(Object[] showArray)
	{
		for (int i=0; i<showArray.length; i++)
		{
			System.out.println("Value at [" + (i+1) + "] is [" + String.valueOf(showArray[i]) + "]");
		}
	}
	
	//displayTable
	public void displayTable(String[] sChapter, String[] sTitle, String[] sPage)
	{
		//Print the TOC first line
		System.out.println("Chapter Title \t\t\t\t\t\t\t\t\t Page");
		
		for (int i=0; i<TableSorter.chapter.length; i++)
		{
			//System.out.println("\t" + chapter[i] + " " + title[i]+ "\t" + page[i]);
			System.out.printf("%5s %-75s %-10s \n", chapter[i], title[i], page[i]);
		}
	}



}
