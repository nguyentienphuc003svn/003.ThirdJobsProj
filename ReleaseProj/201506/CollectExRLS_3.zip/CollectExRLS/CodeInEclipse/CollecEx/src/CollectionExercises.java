import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

/**
 * Exercises for practicing with Java collection types.
 * 
 * @author Nathan Sprague and ...
 * 
 */
public class CollectionExercises
{

	/**
	 * This method removes all values from the provided list that are smaller
	 * than the indicated integer. The remaining elements retain their original
	 * ordering.
	 * 
	 * @param list - the list of integers
	 * @param minVal the minimum value to retain
	 */
	public static void removeSmallInts(List<Integer> list, int minVal)
	{
		// Your solution must use an iterator. Conveniently, the list iterator
		// has a remove method.
		Iterator<Integer> it = list.iterator();

		while (it.hasNext())
		{
			Integer myNumber = it.next();
			if (myNumber < minVal)
			{
				it.remove();
			}
		}
	}

	/**
	 * This method returns a new ArrayList containing all non-duplicate elements
	 * from the provided collection. For example, if the provided collection
	 * contained the values {2, 1, 2, 3}, the returned ArrayList will contain
	 * {1, 2, 3}. The returned values in the ArrayList may be in any order. The
	 * original collection will not be modified.
	 * 
	 * @param ints - a collection of integers
	 * @return an array list containing non-duplicates
	 */
	public static ArrayList<Integer> removeDuplicates(Collection<Integer> ints)
	{
		// THIS SHOULD BE A ONE-LINER. Remember that all of the collection types
		// provide a copy constructor that may be used to instantiate a new
		// collection object using the elements stored in an existing
		// collection.

		ArrayList<Integer> noDup = new ArrayList<Integer>(ints);

//		Iterator<Integer> it = ints.iterator();
//		while(it.hasNext())
//		{
//			Integer ele = it.next();
//			noDup.add(ele);
//		}

		Iterator<Integer> checkIT = noDup.iterator();
		HashMap<Integer, Integer> noDupHM = new HashMap<Integer, Integer>();
		while(checkIT.hasNext())
		{
			Integer noele = checkIT.next();

			if (noDupHM.size() <= 0) noDupHM.put(noele, noele);
			else
			{
				if (!noDupHM.containsKey(noele)) noDupHM.put(noele, noele);
			}
		}

		Iterator<Integer> returnIT = noDupHM.values().iterator();
		noDup.clear();
		while(returnIT.hasNext())
		{
			Integer returnele = returnIT.next();
			noDup.add(returnele);
		}
		return noDup;
	}

	/**
	 * This method returns an ArrayList containing all elements that appear in
	 * either of the two collection arguments. There will be no duplicate values
	 * in the resulting ArrayList. The values in the returned ArrayList may be
	 * in any order.
	 * 
	 * For example, if the two arguments contain {2, 1, 2, 3} and {3, 4, 4, 5},
	 * the returned ArrayList will contain {1, 2, 3, 4, 5}. The original
	 * collections will not be modified.
	 * 
	 * @param ints1 - the first collection
	 * @param ints2 - the second collection
	 * @return An ArrayList containing the integers that appear in either
	 *         collection.
	 */
	public static ArrayList<Integer> inEither(Collection<Integer> ints1, Collection<Integer> ints2)
	{
		// This can be done with no loops.
		ArrayList<Integer> noDup = new ArrayList<Integer>();

		Iterator<Integer> itOne = ints1.iterator();
		while(itOne.hasNext())
		{
			Integer ele = itOne.next();
			noDup.add(ele);
		}

		Iterator<Integer> itTwo = ints2.iterator();
		while(itTwo.hasNext())
		{
			Integer ele = itTwo.next();
			noDup.add(ele);
		}

		ArrayList<Integer> noDupReturn = CollectionExercises.removeDuplicates(noDup);

		return noDupReturn;
	}

	/**
	 * This method returns an ArrayList containing all elements that appear in
	 * both of the two collection arguments. There will be no duplicate values
	 * in the resulting ArrayList. The values in the returned ArrayList may be
	 * in any order. For example, if the two arguments contain {2, 1, 2, 3} and
	 * {3, 4, 4, 5}, the returned ArrayList will contain {3}. The original
	 * collections will not be modified.
	 * 
	 * @param ints1 - the first collection
	 * @param ints2 - the second collection
	 * @return An ArrayList containing the integers that appear in both
	 *         collections.
	 */
	public static ArrayList<Integer> inBoth(Collection<Integer> ints1, Collection<Integer> ints2)
	{
		ArrayList<Integer> noDup = new ArrayList<Integer>();

		Iterator<Integer> itOne = ints1.iterator();
		while(itOne.hasNext())
		{
			Integer ele = itOne.next();
			if (ints2.contains(ele)) noDup.add(ele);
		}

		ArrayList<Integer> noDupReturn = CollectionExercises.removeDuplicates(noDup);

		return noDupReturn;
	}

	/**
	 * This method returns the integer that appears most frequently in the
	 * provided list. For example, if the input list contains the elements {2,
	 * 1, 2, 3, 2}, the return value will be 2. If there are ties, any of the
	 * most frequently occurring integers may be returned.
	 * 
	 * @param list - a list of integers
	 * @return the most frequently occurring String
	 */
	public static String mostFrequent(List<String> list)
	{
		// You should solve this problem in two stages: First iterate through
		// the list to count every String. Then iterate through your counts
		// to find the largest. You'll need a collection that allows you to
		// store a mapping from Strings to counters.
		HashMap<String, Integer> countHM = new HashMap<String, Integer>();

		Iterator<String> itOne = list.iterator();
		while(itOne.hasNext())
		{
			String ele = itOne.next();

			if (countHM.size() <=0) countHM.put(ele, 1);
			else
			{
				if (countHM.containsKey(ele)) 
				{	
					int tempValue = countHM.get(ele)+1;
					countHM.remove(ele);
					countHM.put(ele, tempValue);
					
					//countHM.replace(ele, countHM.get(ele)+1);
				}
				else
					countHM.put(ele, 1);
			}
		}

		Iterator<String> itTwo = countHM.keySet().iterator();
		int max = 0;
		String numReturn= "";
		while(itTwo.hasNext())
		{
			String ele = itTwo.next();

			if (countHM.get(ele) > max) 
			{
				max = countHM.get(ele);
				numReturn = ele;
			} 
					
		}

		return numReturn;
	}

}
