import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;

import org.junit.Before;
import org.junit.Test;

/**
 * Very minimal tests for the CollectionsExercises class. These tests only cover
 * the "easy cases". No error conditions or edge-cases are considered. (For
 * example, what happens when mostFrequent is passed an empty list?) There are
 * also no tests that address the efficiency of the solutions.
 * 
 * @author Nathan Sprague
 * @version 4/21/15
 */
public class CollectionExercisesTest
{

    private LinkedList<Integer> list1;
    private LinkedList<Integer> list2;

    @Before
    public void setUp()
    {
        Integer[] array1 = {8, 8, 1, 3, 3, 7, 0, 3, 3, 7};
        Integer[] array2 = {4, 4, 7, 9, 4, 8, 4, 1, 8, 4};

        list1 = new LinkedList<Integer>(Arrays.asList(array1));
        list2 = new LinkedList<Integer>(Arrays.asList(array2));
    }

    @Test
    public void testRemoveSmallInts()
    {
        Integer[] arrayExpected = {8, 8, 3, 3, 7, 3, 3, 7};
        LinkedList<Integer> expected = new LinkedList<Integer>(Arrays.asList(arrayExpected));
        CollectionExercises.removeSmallInts(list1, 3);
        assertEquals(expected, list1);
    }

    @Test
    public void testRemoveDuplicates()
    {
        Integer[] arrayExpected = {0, 1, 3, 7, 8};
        LinkedList<Integer> expected = new LinkedList<Integer>(Arrays.asList(arrayExpected));
        ArrayList<Integer> result = CollectionExercises.removeDuplicates(list1);
        Collections.sort(result);
        assertEquals(expected, result);
    }

    @Test
    public void testInEither()
    {
        Integer[] arrayExpected = {0, 1, 3, 4, 7, 8, 9};
        LinkedList<Integer> expected = new LinkedList<Integer>(Arrays.asList(arrayExpected));
        ArrayList<Integer> result = CollectionExercises.inEither(list1, list2);
        Collections.sort(result);
        assertEquals(expected, result);
    }

    @Test
    public void testInBoth()
    {
        Integer[] arrayExpected = {1, 7, 8};
        LinkedList<Integer> expected = new LinkedList<Integer>(Arrays.asList(arrayExpected));
        ArrayList<Integer> result = CollectionExercises.inBoth(list1, list2);
        Collections.sort(result);
        assertEquals(expected, result);
    }

    @Test
    public void testMostFrequent()
    {
        String[] array1 = {"A", "B", "C", "A", "A", "B", "C", "D", "E"};
        LinkedList<String> list1 = new LinkedList<String>(Arrays.asList(array1));   
        assertEquals("A", CollectionExercises.mostFrequent(list1));
    }

}