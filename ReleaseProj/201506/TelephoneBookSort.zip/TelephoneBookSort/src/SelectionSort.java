
public class SelectionSort
{

	public static void selectionSort(int[] arr)
	{
		for (int i = 0; i < arr.length - 1; ++i)
		{
			int minIndex = i;
			for (int j = i + 1; j < arr.length; ++j)
			{
				if (arr[j] < arr[minIndex])
				{
					minIndex = j;
				}
			}
			int temp = arr[i];
			arr[i] = arr[minIndex];
			arr[minIndex] = temp;
		}
	}

	public static void selectionSort(String[] arr)
	{
		for (int i = 0; i < arr.length - 1; ++i)
		{
			int minIndex = i;
			for (int j = i + 1; j < arr.length; ++j)
			{
				// "<" changed to use of compareTo()
				if (arr[j].compareTo(arr[minIndex]) < 0)
				{
					minIndex = j;
				}
			}
			
			// int changed to String
			String temp = arr[i];
			arr[i] = arr[minIndex];
			arr[minIndex] = temp;
		}
	}

	public static <T extends Comparable<T>> void selectionSort(T[] arr)
	{
		for (int i = 0; i < arr.length - 1; ++i)
		{
			int minIndex = i;
			for (int j = i + 1; j < arr.length; ++j)
			{
				if (arr[j].compareTo(arr[minIndex]) < 0)
				{
					minIndex = j;
				}
			}
			// String changed to T
			T temp = arr[i];
			arr[i] = arr[minIndex];
			arr[minIndex] = temp;
		}
	}
}
