(function(){
        var Array = function(){};
        return new Array(1, 2, 3, 4);
})();
