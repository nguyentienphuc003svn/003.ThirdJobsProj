a:break a;console.log(1)
