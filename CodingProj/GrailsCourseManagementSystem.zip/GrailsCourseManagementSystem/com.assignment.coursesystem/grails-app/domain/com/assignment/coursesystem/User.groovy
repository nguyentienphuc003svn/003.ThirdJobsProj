package com.assignment.coursesystem

class User {

    static constraints = {
    }

	String studentid	
	String password
	String firstname
	String lastname
	String birthday
	String address
	String tel	
	
}
