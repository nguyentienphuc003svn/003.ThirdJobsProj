package com.assignment.coursesystem

class Course {

    static constraints = {
    }
	
	String courseid
	String coursename
	String credit
}
