package com.assignment.coursesystem

class Enrollment {

    static constraints = {
    }
	
	String studentid
	String courseid
	String coursename
	
}
