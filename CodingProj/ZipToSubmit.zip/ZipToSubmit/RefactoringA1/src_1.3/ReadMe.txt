
� (a) What bad smell in the previous version was removed and using which refactoring.
class CheckingAccount � Need to extract class


� (b) What bad smell is now going to be dealt with and using which refactoring.
class CreditCard � Need to extract class
