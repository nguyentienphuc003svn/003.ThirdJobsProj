
� (a) What bad smell in the previous version was removed and using which refactoring.
class DebitCard - boolean pay(double amount)  - Need to move to CheckingAccount class


� (b) What bad smell is now going to be dealt with and using which refactoring.
class CheckingAccount � Need to extract class
