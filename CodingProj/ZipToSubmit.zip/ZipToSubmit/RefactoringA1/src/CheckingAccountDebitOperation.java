

public class CheckingAccountDebitOperation {
	private double fBalance;

	public double getFBalance() {
		return fBalance;
	}

	public void setFBalance(double fBalance) {
		this.fBalance = fBalance;
	}

	public void determineCosts() {
		fBalance = fBalance - CheckingAccount.costs;
		if (fBalance < 0) {
			fBalance = fBalance - (fBalance * CheckingAccount.debitRate / 100);
		}
	}

	public boolean applyForCreditCard(String name, String street,
			String zipCode, String town, String country, int accountNumber) {
		if (fBalance < 0) {
			return false;
		}
		if (fBalance <= 2500) {
			CheckingAccount.fCreditCard = new CreditCard(name, street, town,
					zipCode, country);
		} else {
			CheckingAccount.fCreditCard = new CreditCard(name, street, town,
					zipCode, country, 5000);
		}
		return true;
	}
}