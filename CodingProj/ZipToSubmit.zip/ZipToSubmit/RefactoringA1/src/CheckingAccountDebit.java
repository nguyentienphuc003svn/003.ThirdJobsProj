
public class CheckingAccountDebit {
	private boolean fDebitAllowed;

	public boolean getFDebitAllowed() {
		return fDebitAllowed;
	}

	public void setFDebitAllowed(boolean fDebitAllowed) {
		this.fDebitAllowed = fDebitAllowed;
	}

	public boolean withdrawal(double amount, CheckingAccount checkingAccount,
			double fBalance, double fDebitAmount) {
		if (((fBalance - amount) < 0) && (!fDebitAllowed)) {
			return false;
		} else if ((fBalance - amount) < -fDebitAmount) {
			checkingAccount.verseMoney(fBalance - amount);
			return true;
		} else {
			return false;
		}
	}
}