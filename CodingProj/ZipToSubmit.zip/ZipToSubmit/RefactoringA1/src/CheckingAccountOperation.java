
public class CheckingAccountOperation {
	private double fDebitAmount;

	public double getFDebitAmount() {
		return fDebitAmount;
	}

	public void setFDebitAmount(double fDebitAmount) {
		this.fDebitAmount = fDebitAmount;
	}

	public boolean pay(double amount, double fBalance,
			CheckingAccount checkingAccount) {
		if ((fBalance - amount) < -fDebitAmount) {
			checkingAccount.setBalance(fBalance - amount);
			return true;
		} else {
			return false;
		}
	}
}