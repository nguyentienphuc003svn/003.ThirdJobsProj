import java.util.Vector;


public class Bank 
{
	private BankProductChecking bankProductChecking = new BankProductChecking();
	private BankProduct bankProduct = new BankProduct();
	private String fName;

	public Bank(String name)
	{
		fName = name;
		bankProductChecking.setFCheckingAccounts(new Vector<CheckingAccount>());
		bankProduct.setFSavingAccounts(new Vector<SavingsAccount>());
	}

	public int openSimpleCheckingAccount()
	{
		return bankProductChecking.openSimpleCheckingAccount();
	}

	public boolean withdrawMoney(int accountNumber, double amount)
	{
		return bankProductChecking.withdrawMoney(accountNumber, amount);
	}

}
