import java.util.Vector;

public class BankProduct {
	private Vector<SavingsAccount> fSavingAccounts;

	public Vector<SavingsAccount> getFSavingAccounts() {
		return fSavingAccounts;
	}

	public void setFSavingAccounts(Vector<SavingsAccount> fSavingAccounts) {
		this.fSavingAccounts = fSavingAccounts;
	}

	public int openFullPackage(Vector<CheckingAccount> fCheckingAccounts) {
		CheckingAccount newAccount = new CheckingAccount("Bob Smith",
				"1 Main St.", "12345", "Tacoma", "USA");
		fCheckingAccounts.add(newAccount);
		newAccount.applyForCreditCard("Bob Smith", "1 Main St.", "12345",
				"Tacoma", "USA", newAccount.getAccountNumber());
		SavingsAccount newSavingsAccount = new SavingsAccount("Bob Smith",
				"1 Main St.", "12345", "Tacoma", "USA");
		fSavingAccounts.add(newSavingsAccount);
		DebitCard newDebetCard = new DebitCard("Bob Smith", "1 Main St.",
				"12345", "Tacoma", "USA", 0, newAccount);
		return newAccount.getAccountNumber();
	}
}