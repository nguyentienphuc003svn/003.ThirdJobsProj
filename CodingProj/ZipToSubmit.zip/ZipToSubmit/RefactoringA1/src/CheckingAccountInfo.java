

public class CheckingAccountInfo {
	private String fName;
	private String fStreet;
	private String fZipcode;
	private String fTown;
	private String fCountry;

	public String getFName() {
		return fName;
	}

	public void setFName(String fName) {
		this.fName = fName;
	}

	public String getFStreet() {
		return fStreet;
	}

	public void setFStreet(String fStreet) {
		this.fStreet = fStreet;
	}

	public String getFZipcode() {
		return fZipcode;
	}

	public void setFZipcode(String fZipcode) {
		this.fZipcode = fZipcode;
	}

	public String getFTown() {
		return fTown;
	}

	public void setFTown(String fTown) {
		this.fTown = fTown;
	}

	public String getFCountry() {
		return fCountry;
	}

	public void setFCountry(String fCountry) {
		this.fCountry = fCountry;
	}

	public void print(int fAccountNumber, double fBalance) {
		System.out.println("**************************************");
		System.out.println("Savings account:     " + fAccountNumber);
		System.out.println("Account holder name: " + fName);
		System.out.println("Address:             " + fStreet);
		System.out.print("                     " + fZipcode);
		System.out.println(" " + fTown);
		System.out.println(fCountry.toUpperCase());
		System.out.println("**************************************");
		System.out.println("Balance:  " + fBalance);
		System.out.println("**************************************");
	}
}