import java.util.Vector;

public class BankProductChecking {
	private Vector<CheckingAccount> fCheckingAccounts;

	public Vector<CheckingAccount> getFCheckingAccounts() {
		return fCheckingAccounts;
	}

	public void setFCheckingAccounts(Vector<CheckingAccount> fCheckingAccounts) {
		this.fCheckingAccounts = fCheckingAccounts;
	}

	public int openSimpleCheckingAccount() {
		CheckingAccount newAccount = new CheckingAccount("Bob Smith",
				"1 Main St.", "12345", "Tacoma", "USA");
		fCheckingAccounts.add(newAccount);
		return newAccount.getAccountNumber();
	}

	public boolean withdrawMoney(int accountNumber, double amount) {
		CheckingAccount account = new CheckingAccount(accountNumber);
		int index = fCheckingAccounts.indexOf(account);
		return fCheckingAccounts.elementAt(index).withdrawal(amount);
	}
}