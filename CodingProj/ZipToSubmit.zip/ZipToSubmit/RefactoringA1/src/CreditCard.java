
public class CreditCard 
{
	private CreditCardLimit creditCardLimit = new CreditCardLimit();
	
	private static int fLastCreditCardNumber;
	private int fAccountConnectedTo;
	private int fCreditCardNumber;
	private String fName;
	private String fStreet;
	private String fTown;
	private String fzipCode;
	private String fCountry;
	
	public CreditCard(String name, String street, String town, String zipCode, String country)
	{
		fName = name;
		fStreet = street;
		fTown = town;
		fzipCode = zipCode;
		fCountry = country;
		creditCardLimit.setFLimit(2500); // standard limit
		creditCardLimit.setFBalance(0);
	}
	
	public CreditCard(String name, String street, String town, String zipCode, String country, double limit)
	{
		fName = name;
		fStreet = street;
		fTown = town;
		fzipCode = zipCode;
		fCountry = country;
		creditCardLimit.setFLimit(limit);
		creditCardLimit.setFBalance(0);
	}
}
