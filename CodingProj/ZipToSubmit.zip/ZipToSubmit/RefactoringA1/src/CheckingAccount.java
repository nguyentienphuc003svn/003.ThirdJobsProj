
public class CheckingAccount 
{
	private CheckingAccountDebitOperation checkingAccountDebitOperation = new CheckingAccountDebitOperation();
	private CheckingAccountOperation checkingAccountOperation = new CheckingAccountOperation();
	private CheckingAccountInfo checkingAccountInfo = new CheckingAccountInfo();
	private CheckingAccountDebit checkingAccountDebit = new CheckingAccountDebit();

	private int fAccountNumber;
	public static double costs = 1; // per period there is a cost associated with this account
									// that equals 1 pound
	public static double debitRate = 4.7;
	public static CreditCard fCreditCard;
	private static SavingsAccount fSavingsAccount;
	private static DebitCard fDebitCard;
	private static int fNextAccountNumber = 0;

	public CheckingAccount(String name, String street, String zipcode, String town, String country)
	{
		checkingAccountInfo.setFName(name);
		checkingAccountInfo.setFStreet(street);
		checkingAccountInfo.setFZipcode(zipcode);
		checkingAccountInfo.setFTown(town);
		checkingAccountInfo.setFCountry(country);
		fAccountNumber = fNextAccountNumber;
		fNextAccountNumber++;
		checkingAccountDebit.setFDebitAllowed(false);
		checkingAccountOperation.setFDebitAmount(0);

	}

	public CheckingAccount(String name, String street, String zipCode, String town, String country, float debit)
	{
		checkingAccountInfo.setFName(name);
		checkingAccountInfo.setFStreet(street);
		checkingAccountInfo.setFZipcode(zipCode);
		checkingAccountInfo.setFTown(town);
		checkingAccountInfo.setFCountry(country);
		fAccountNumber = fNextAccountNumber;
		fNextAccountNumber++;
		checkingAccountDebit.setFDebitAllowed(true);
		checkingAccountOperation.setFDebitAmount(debit);
	}

	public CheckingAccount(int accountnumber)
	{
		fAccountNumber = accountnumber;
	}

	public boolean withdrawal(double amount)
	{
		return checkingAccountDebit.withdrawal(amount, this, checkingAccountDebitOperation.getFBalance(),
				checkingAccountOperation.getFDebitAmount());
	}

	public void verseMoney(double amount)
	{
		checkingAccountDebitOperation.setFBalance(amount);
	}

	public boolean applyForCreditCard(String name, String street, String zipCode, String town, String country, int accountNumber)
	{
		return checkingAccountDebitOperation.applyForCreditCard(name, street, zipCode,
				town, country, accountNumber);
	}

	public double getBalance()
	{
		return checkingAccountDebitOperation.getFBalance();
	}

	public void increaseBalance(double amount)
	{
		checkingAccountDebitOperation.setFBalance(amount);
	}

	public void decreaseBalance(double amount)
	{
		checkingAccountDebitOperation.setFBalance(amount);
	}

	public double getDebitAmount()
	{
		return checkingAccountOperation.getFDebitAmount();
	}

	public void setBalance(double amount)
	{
		checkingAccountDebitOperation.setFBalance(amount);	
	}

	public int getAccountNumber() 
	{
		return fAccountNumber;	
	}

	public boolean equals(Object o)
	{
		if(fAccountNumber == ((CheckingAccount)o).fAccountNumber)
			return true;
		else
			return false;

	}
}
