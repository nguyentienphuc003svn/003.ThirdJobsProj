

public class CreditCardLimit {
	private double fLimit;
	private double fBalance;

	public double getFLimit() {
		return fLimit;
	}

	public void setFLimit(double fLimit) {
		this.fLimit = fLimit;
	}

	public double getFBalance() {
		return fBalance;
	}

	public void setFBalance(double fBalance) {
		this.fBalance = fBalance;
	}

	public boolean pay(double amount) {
		if ((fBalance - amount) < -fLimit) {
			fBalance -= amount;
			return true;
		} else {
			return false;
		}
	}
}