
public class TestCase {

	public static void main(String[] args) {
		
		Bank bank = new Bank("Bank of America");
		
		//Test for account number
		System.out.println("The Acc Number is: " + bank.openSimpleCheckingAccount());// Result is 0
		System.out.println("The Acc Number is: " + bank.openSimpleCheckingAccount());// Result is 1

		//////////////////Test the Checking Account
		CheckingAccount ck = new CheckingAccount("Name", "Street", "Zipcode", "Town", "Country");
		System.out.println("The withdraw amount is: " + ck.withdrawal(100.0));// Result is false
		
		ck.verseMoney(200.0);
		System.out.println("The amount is: " + ck.getBalance());//200.0
		
		ck.increaseBalance(150.0);
		System.out.println("The amount is: " + ck.getBalance());//150.0

		//////////////////Test the Saving Account
		SavingsAccount sv = new SavingsAccount("Name", "Street", "Zipcode", "Town", "Country");
		sv.getSavingsAccountBalanceInfo().verseMoney(200.0);
		System.out.println("The amount is: " + sv.getSavingsAccountBalanceInfo().getSavingsAccountInfo().getSavingsAccountBalance().getFBalance());//200.0
		
		System.out.println("\n\n");
		sv.getSavingsAccountBalanceInfo().getSavingsAccountInfo().print();
		System.out.println("\n\n");
		
		sv.getSavingsAccountBalanceInfo().getSavingsAccountInfo().getSavingsAccountBalance().withdrawal(50.0);
		System.out.println("The amount is: " + sv.getSavingsAccountBalanceInfo().getSavingsAccountInfo().getSavingsAccountBalance().getFBalance());//150.0
	
	}
}
