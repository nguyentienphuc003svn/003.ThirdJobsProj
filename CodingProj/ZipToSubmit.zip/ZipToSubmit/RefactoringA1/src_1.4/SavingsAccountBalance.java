

public class SavingsAccountBalance {
	private double fBalance;

	public double getFBalance() {
		return fBalance;
	}

	public void setFBalance(double fBalance) {
		this.fBalance = fBalance;
	}

	public void calculateInterest() {
		fBalance = fBalance + (fBalance * SavingsAccount.interestRate / 100);
	}

	public boolean withdrawal(double amount) {
		if (((fBalance - amount) < 0)) {
			return false;
		} else {
			fBalance = fBalance - amount;
			return true;
		}
	}
}