
public class SavingsAccount {
	private SavingsAccountBalanceInfo savingsAccountBalanceInfo = new SavingsAccountBalanceInfo();
	private static double costssavingsAccountBalanceInfo = 1; 	// per period there is a cost associated with this account
																// that equals 1 pound
	
	public static double interestRate = 1.25;
	private static int fNextAccountNumber = 0;
	
	public SavingsAccount(String name, String street, String zipCode, String town, String country)
	{
		savingsAccountBalanceInfo.getSavingsAccountInfo().setFName(name);
		savingsAccountBalanceInfo.getSavingsAccountInfo().setFStreet(street);
		savingsAccountBalanceInfo.getSavingsAccountInfo().setFZipCode(zipCode);
		savingsAccountBalanceInfo.getSavingsAccountInfo().setFTown(town);
		savingsAccountBalanceInfo.getSavingsAccountInfo().setFCountry(country);
		savingsAccountBalanceInfo.getSavingsAccountInfo().setFAccountNumber(fNextAccountNumber);
		fNextAccountNumber++;
	}	
	
}
