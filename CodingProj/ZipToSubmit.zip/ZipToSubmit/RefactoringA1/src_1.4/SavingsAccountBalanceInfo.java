

public class SavingsAccountBalanceInfo {
	private SavingsAccountInfo savingsAccountInfo = new SavingsAccountInfo();

	public SavingsAccountInfo getSavingsAccountInfo() {
		return savingsAccountInfo;
	}

	public void setSavingsAccountInfo(SavingsAccountInfo savingsAccountInfo) {
		this.savingsAccountInfo = savingsAccountInfo;
	}

	public void verseMoney(double amount) {
		savingsAccountInfo.getSavingsAccountBalance().setFBalance(amount);
	}
}