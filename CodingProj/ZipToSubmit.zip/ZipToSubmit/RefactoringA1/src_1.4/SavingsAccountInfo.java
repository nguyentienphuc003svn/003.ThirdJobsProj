

public class SavingsAccountInfo {
	private SavingsAccountBalance savingsAccountBalance = new SavingsAccountBalance();
	private int fAccountNumber;
	private String fName;
	private String fStreet;
	private String fZipCode;
	private String fTown;
	private String fCountry;

	public SavingsAccountBalance getSavingsAccountBalance() {
		return savingsAccountBalance;
	}

	public void setSavingsAccountBalance(
			SavingsAccountBalance savingsAccountBalance) {
		this.savingsAccountBalance = savingsAccountBalance;
	}

	public int getFAccountNumber() {
		return fAccountNumber;
	}

	public void setFAccountNumber(int fAccountNumber) {
		this.fAccountNumber = fAccountNumber;
	}

	public String getFName() {
		return fName;
	}

	public void setFName(String fName) {
		this.fName = fName;
	}

	public String getFStreet() {
		return fStreet;
	}

	public void setFStreet(String fStreet) {
		this.fStreet = fStreet;
	}

	public String getFZipCode() {
		return fZipCode;
	}

	public void setFZipCode(String fZipCode) {
		this.fZipCode = fZipCode;
	}

	public String getFTown() {
		return fTown;
	}

	public void setFTown(String fTown) {
		this.fTown = fTown;
	}

	public String getFCountry() {
		return fCountry;
	}

	public void setFCountry(String fCountry) {
		this.fCountry = fCountry;
	}

	public void print() {
		System.out.println("**************************************");
		System.out.println("Savings account:     " + fAccountNumber);
		System.out.println("Account holder name: " + fName);
		System.out.println("Address:             " + fStreet);
		System.out.print("                     " + fZipCode);
		System.out.println(" " + fTown);
		System.out.println(fCountry.toUpperCase());
		System.out.println("**************************************");
		System.out.println("Balance:  " + savingsAccountBalance.getFBalance());
		System.out.println("**************************************");
	}
}