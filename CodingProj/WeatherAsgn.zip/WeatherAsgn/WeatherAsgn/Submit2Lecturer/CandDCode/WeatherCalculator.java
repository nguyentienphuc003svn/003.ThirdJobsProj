package pa1;

import java.util.ArrayList;
import java.util.Iterator;


public class WeatherCalculator {
		
	public static WeatherDatum findClosest(double windChill, double stepSizeTemperature, double stepSizeWindSpeed)
	{
		double allowTemperature = Numerical.project(stepSizeTemperature, WeatherDatum.ALLOWABLE_TEMPERATURES);
		double allowWindSpeed = Numerical.project(stepSizeWindSpeed, WeatherDatum.ALLOWABLE_WIND_SPEEDS);
		WeatherDatum closetWD = null;
		
		//Temperature Set
		ArrayList<Double> TemperatureSet = new ArrayList<Double>();
		double minTemperature = WeatherDatum.ALLOWABLE_TEMPERATURES[0];
		double maxTemperature = WeatherDatum.ALLOWABLE_TEMPERATURES[1];
		double tempTemperature = minTemperature;
		int increaseTemperature = 1;
		
		while (tempTemperature < maxTemperature)
		{
			TemperatureSet.add(tempTemperature);
			
			tempTemperature = minTemperature + increaseTemperature*allowTemperature;
			increaseTemperature++;
		}
		TemperatureSet.add(maxTemperature);
		
		//WindSpeed Set
		ArrayList<Double> WindSpeedSet = new ArrayList<Double>();
		double minWindSpeed = WeatherDatum.ALLOWABLE_WIND_SPEEDS[0];
		double maxWindSpeed = WeatherDatum.ALLOWABLE_WIND_SPEEDS[1];
		double tempWindSpeed = minWindSpeed;
		int increaseWindSpeed = 1;
		
		while (tempWindSpeed < maxWindSpeed)
		{
			WindSpeedSet.add(tempWindSpeed);
			
			tempWindSpeed = minWindSpeed + increaseWindSpeed*allowWindSpeed;
			increaseWindSpeed++;
		}
		WindSpeedSet.add(maxWindSpeed);
		
		//Find the Closet
		Iterator<Double> temperatureIT = TemperatureSet.iterator();
		double compareWindChild = 0d;		
		
		while(temperatureIT.hasNext())
		{
			double pairTemperature = Numerical.project(temperatureIT.next(), WeatherDatum.ALLOWABLE_TEMPERATURES);
			double pairWindSpeed = 0d;
			
			Iterator<Double> WindSpeedIT = WindSpeedSet.iterator();
			while(WindSpeedIT.hasNext())
			{
				pairWindSpeed = Numerical.project(WindSpeedIT.next(), WeatherDatum.ALLOWABLE_WIND_SPEEDS);
				
				WeatherDatum wd = new WeatherDatum(pairTemperature, pairWindSpeed);				
				double closetWindChill = wd.getWindChill(pairTemperature, pairWindSpeed);
				
				if (compareWindChild == 0d)
				{
					compareWindChild = Math.abs(closetWindChill);
					closetWD = wd;
				}
				if (Math.abs(closetWindChill-windChill) <= compareWindChild)
				{
					compareWindChild = Math.abs(closetWindChill-windChill);
					closetWD = wd;
				}
			}
		}
		
		return closetWD;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
