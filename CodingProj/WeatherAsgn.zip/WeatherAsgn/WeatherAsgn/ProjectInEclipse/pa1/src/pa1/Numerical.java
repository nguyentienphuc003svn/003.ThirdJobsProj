package pa1;

public class Numerical {
	
	public static double project(double number, double[] interval)	
	{
		if (interval.length <= 0 || interval == null) return number;
		else if (interval.length == 1) return interval[0];
		else
		{
			double lowerBound = interval[0];
			double upperBound = interval[1];
			
			if (number >= lowerBound && number<= upperBound) return number;
			else if (number < lowerBound) return lowerBound;
			else return upperBound;
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
