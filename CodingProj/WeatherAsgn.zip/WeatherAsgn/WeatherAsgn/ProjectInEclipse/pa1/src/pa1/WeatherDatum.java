package pa1;

public class WeatherDatum {
	
	public static final double FREEZING_POINT = 32.0;
	public static final double[] ALLOWABLE_TEMPERATURES = {-150, 150};  
	public static final double[] ALLOWABLE_WIND_SPEEDS  = {0, 200};
	
	private double temperature;
	private double windSpeed;
	
	public WeatherDatum (double temperature, double windSpeed)
	{
		this.temperature = Numerical.project(temperature, ALLOWABLE_TEMPERATURES);
		this.windSpeed = Numerical.project(windSpeed, ALLOWABLE_WIND_SPEEDS);
		
		this.getWindChill(this.temperature, this.windSpeed);
	}
	
	public double getTemperature()
	{
		return this.temperature;
	}
	
	public double getWindSpeed()
	{
		return this.windSpeed;
	}
	
	public boolean isBelowFreezing()
	{
		return this.temperature < FREEZING_POINT ? true : false;
	}
	
	public double getWindChill(double temperature, double windSpeed)
	{
		return 35.74 + 0.6215*temperature - 35.75*Math.pow(windSpeed, 0.16) + 0.4275*temperature*Math.pow(windSpeed, 0.16);
	}
	

	public static void main(String[] args) {
		
		//Test with Temperature=100.0 and WindSpeed=20.0
		WeatherDatum wd = new WeatherDatum(100.0, 20.0);		
		System.out.println("Is that the Temperature is Below the Freezing : " + wd.isBelowFreezing());
		System.out.println("The Wind Chill is: " + String.format("%.2f", wd.getWindChill(100.0, 20.0)));
		
		//Test with Temperature=10.0 and WindSpeed=120.0
		WeatherDatum wd2 = new WeatherDatum(10.0, 120.0);		
		System.out.println("\nIs that the Temperature is Below the Freezing : " + wd2.isBelowFreezing());
		System.out.println("The Wind Chill is: " + String.format("%.2f", wd2.getWindChill(10.0, 120.0)));
		
		//Test with Temperature=-10.0 and WindSpeed=320.0
		WeatherDatum wd3 = new WeatherDatum(-10.0, 320.0);		
		System.out.println("\nIs that the Temperature is Below the Freezing : " + wd3.isBelowFreezing());
		System.out.println("The Wind Chill is: " + String.format("%.2f", wd3.getWindChill(-10.0, 320.0)));

	}
}
