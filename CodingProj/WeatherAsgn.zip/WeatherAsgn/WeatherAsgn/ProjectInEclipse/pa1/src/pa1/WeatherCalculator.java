package pa1;

import java.util.ArrayList;
import java.util.Iterator;


public class WeatherCalculator {
		
	public static WeatherDatum findClosest(double windChill, double stepSizeTemperature, double stepSizeWindSpeed)
	{
		double allowTemperature = Numerical.project(stepSizeTemperature, WeatherDatum.ALLOWABLE_TEMPERATURES);
		double allowWindSpeed = Numerical.project(stepSizeWindSpeed, WeatherDatum.ALLOWABLE_WIND_SPEEDS);
		WeatherDatum closetWD = null;
		
		//Temperature Set
		ArrayList<Double> TemperatureSet = new ArrayList<Double>();
		double minTemperature = WeatherDatum.ALLOWABLE_TEMPERATURES[0];
		double maxTemperature = WeatherDatum.ALLOWABLE_TEMPERATURES[1];
		double tempTemperature = minTemperature;
		int increaseTemperature = 1;
		
		while (tempTemperature < maxTemperature)
		{
			TemperatureSet.add(tempTemperature);
			
			tempTemperature = minTemperature + increaseTemperature*allowTemperature;
			increaseTemperature++;
		}
		TemperatureSet.add(maxTemperature);
		
		//WindSpeed Set
		ArrayList<Double> WindSpeedSet = new ArrayList<Double>();
		double minWindSpeed = WeatherDatum.ALLOWABLE_WIND_SPEEDS[0];
		double maxWindSpeed = WeatherDatum.ALLOWABLE_WIND_SPEEDS[1];
		double tempWindSpeed = minWindSpeed;
		int increaseWindSpeed = 1;
		
		while (tempWindSpeed < maxWindSpeed)
		{
			WindSpeedSet.add(tempWindSpeed);
			
			tempWindSpeed = minWindSpeed + increaseWindSpeed*allowWindSpeed;
			increaseWindSpeed++;
		}
		WindSpeedSet.add(maxWindSpeed);
		
		//Find the Closet
		Iterator<Double> temperatureIT = TemperatureSet.iterator();
		double compareWindChild = 0d;		
		
		while(temperatureIT.hasNext())
		{
			double pairTemperature = Numerical.project(temperatureIT.next(), WeatherDatum.ALLOWABLE_TEMPERATURES);
			double pairWindSpeed = 0d;
			
			Iterator<Double> WindSpeedIT = WindSpeedSet.iterator();
			while(WindSpeedIT.hasNext())
			{
				pairWindSpeed = Numerical.project(WindSpeedIT.next(), WeatherDatum.ALLOWABLE_WIND_SPEEDS);
				
				WeatherDatum wd = new WeatherDatum(pairTemperature, pairWindSpeed);				
				double closetWindChill = wd.getWindChill(pairTemperature, pairWindSpeed);
				
				if (compareWindChild == 0d)
				{
					compareWindChild = Math.abs(closetWindChill);
					closetWD = wd;
				}
				if (Math.abs(closetWindChill-windChill) <= compareWindChild)
				{
					compareWindChild = Math.abs(closetWindChill-windChill);
					closetWD = wd;
				}
			}
		}
		
		return closetWD;
	}

	public static void main(String[] args) {
		
		//Test 1
		WeatherCalculator wc = new WeatherCalculator();
		WeatherDatum wd = wc.findClosest(20.0, 100.0, 120.0);
		System.out.println("The closet Wind Chill has the Temperature is " + wd.getTemperature());
		System.out.println("The closet Wind Chill has the WindSpeed is " + wd.getWindSpeed());
		
		//Test 2
		WeatherCalculator wc2 = new WeatherCalculator();
		WeatherDatum wd2 = wc2.findClosest(70.0, 110.0, 30.0);
		System.out.println("\nThe closet Wind Chill has the Temperature is " + wd2.getTemperature());
		System.out.println("The closet Wind Chill has the WindSpeed is " + wd2.getWindSpeed());
	
	}

}
