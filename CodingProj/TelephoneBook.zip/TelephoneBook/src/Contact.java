
public class Contact {
	
	private String name;
	private String telephone;
	
	public void setName(String name)
	{
		this.name = name;
	}
	
	public void setTelephone(String telephone)
	{
		this.telephone = telephone;
	}
	
	public String getName()
	{
		return this.name;
	}
	
	public String getTelephone()
	{
		return this.telephone;
	}

}
