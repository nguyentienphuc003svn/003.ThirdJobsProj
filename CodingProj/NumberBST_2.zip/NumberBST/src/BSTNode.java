
public class BSTNode {
	protected BSTNode parent = null; // the parent of that node in the BST tree
	protected BSTNode left = null; // the left child of that node in the BST tree
	protected BSTNode right = null; // the right child of that node in the BST tree

	protected Integer number; // the key of the element stored at that node
	protected Integer repeat; // the value of the element stored at that node

	public static BSTNode[] nodeArray;
	public static int index = 0;

	public BSTNode (BSTNode parent, BSTNode left, BSTNode right, Integer key, Integer value)
	{
		this.parent = parent;
		this.left = left;
		this.right = right;
		this.number = key;
		this.repeat = value;
	}

	/*
	 * Checks if this node is the root of the tree. 
	 * Returns true if it is the root, false otherwise.
	 */
	protected boolean isRoot(){
		if (this.getParent() == null) return true;
		else return false;
	}

	/*
	 * Checks if this node is an internal node. 
	 * Returns true if it is internal node, false otherwise.
	 */
	protected boolean isInternal(){
		if (this.isRoot() == true) return false;
		else
		{
			if (this.left != null || this.right != null) return true;
			else return false;
		}
	}

	/*
	 * Checks if this node is an external node. 
	 * Returns true if it is external node, false otherwise.
	 */
	protected boolean isExternal(){
		if (this.isRoot() == true) return false;
		else
		{
			if (this.left == null && this.right == null) return true;
			else return false;
		}	
	}

	protected BSTNode getLeftChild(){
		if (this.isExternal() == true) return null;
		else return this.left;
	}

	protected BSTNode getRightChild(){
		if (this.isExternal() == true) return null;
		else return this.right;
	}

	protected BSTNode getParent(){
		if (this.parent == null) return null;
		else return this.parent;
	}

	public BSTNode search(String key) 
	{
		//
		String NodeKey = String.valueOf(this.number);
		String SearchKey = key;

		//		
		if (SearchKey.compareTo(NodeKey) == 0)
			return this;
		else if (SearchKey.compareTo(NodeKey) < 0) 
		{
			if (left == null) return null;
			else return left.search(key);
		} 
		else if (SearchKey.compareTo(NodeKey) > 0) 
		{
			if (right == null)	return null;
			else return right.search(key);
		}

		return null;
	}

	public BSTNode add(String key, String value) 
	{
		//
		Integer NodeKey = this.number;
		Integer SearchKey = Integer.parseInt(key.trim());

		//		
		if (SearchKey == NodeKey) 
		{			
			this.repeat = Integer.parseInt(value.trim());
			System.out.println("Increase Key " + this.number + " With Value " + this.repeat);
			return this;
		}
		else if (SearchKey < NodeKey) 
		{
			if (left == null) 
			{	
				left = new BSTNode(this, null, null, Integer.parseInt(key.trim()), Integer.parseInt(value.trim()));	
				System.out.println("Added Key " + Integer.parseInt(key.trim()) + " With Value " + Integer.parseInt(value.trim()));
				return null;
			}
			else return left.add(key, value);
		} 
		else if (SearchKey > NodeKey) 
		{
			if (right == null)	
			{	
				right = new BSTNode(this, null, null, Integer.parseInt(key.trim()), Integer.parseInt(value.trim()));
				System.out.println("Added Key " + Integer.parseInt(key.trim()) + " With Value " + Integer.parseInt(value.trim()));				
				return null;
			}
			else return right.add(key, value);
		}

		return null;
	}

	public BSTNode delete(String key) 
	{
		//
		Integer NodeKey;
		Integer SearchKey;
		try
		{
			NodeKey = this.number;
			SearchKey = Integer.parseInt(key);
		}
		catch(Exception e)
		{
			System.out.println("Node Number and Search Key should contains NUMBER only");
			e.getMessage();
			e.toString();
			e.printStackTrace();

			return null;
		}

		//		
		if (SearchKey == NodeKey)
		{	
			return this;
		}
		else if (SearchKey < NodeKey) 
		{
			if (left == null) return null;
			else return left.search(key);
		} 
		else if (SearchKey > NodeKey) 
		{
			if (right == null)	return null;
			else return right.search(key);
		}

		return null;
	}

	public int countNode(BSTNode node)
	{
		if (node == null) return 0;
		if (node.left == null && node.right == null) return 1;
		int left  = countNode(node.left);
		int right = countNode(node.right);
		return 1 + left + right;
	}

	public BSTNode[] printInOrderRec(BSTNode root){
		if (root == null)
		{	
			return null; 
		}		
		printInOrderRec(root.left);

		BSTNode.nodeArray[BSTNode.index] = root;
		BSTNode.index++;
		printInOrderRec(root.right);

		return BSTNode.nodeArray;
	}
}
