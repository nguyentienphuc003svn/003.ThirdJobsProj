
public class MyTest {
	
	public static Integer[] testInt = new Integer[]{0,1,2,3,4,5,6,7,8,9,2,4,6,8,3,5,7,9}; 

	public static void main(String[] args) {
		
		NumberBSTMap mbp = new NumberBSTMap();
		
		//Test for insert
		System.out.println("\nInsert");
		for (Integer i : testInt) 
		{
			//System.out.println("Process Number " + i);
			mbp.insert(i);
		}
		
		//Test for delete
		/*
		 * Deletes the node that has the given key. 
		 * Returns null if the key was not found, otherwise it returns the associated value.
		 */
		System.out.println("\nDelete");
		System.out.println("Result " + String.valueOf(mbp.delete("9")));//Expect 2
		System.out.println("Result " + String.valueOf(mbp.delete("17")));//Expect null
		
		//Test for search
		/*
		 * Search the node that has the given key. 
		 * Returns null if the key was not found, otherwise it returns the associated key and value.
		 */
		System.out.println("\nSearch");
		BSTNode foundNode = mbp.search("9"); 
		
		if (foundNode != null)
		{
			System.out.println("Found number " + foundNode.number + " with repeat times " + foundNode.repeat);
		}
		else
		{
			System.out.println("Cannot find Item 9");
		}
		
		//InOrder Showing
		System.out.println("\nInOrder");
		for (BSTNode testN : mbp.inOrder()) 
		{
			System.out.println("Node number " + testN.number + " with repeat times " + testN.repeat);
		}
		
		//PreOrder Showing
		System.out.println("\nPreOrder");
		mbp.printPreOrderRec(mbp.root);
		
		//PostOrder Showing
		System.out.println("\nPostOrder");
		mbp.printPostOrderRec(mbp.root);
		
		//SumTotal Showing
		System.out.println("\nSumTotal");
		System.out.println("The Sum Total is " + mbp.SumTotal());
		
		//Balance Showing
		System.out.println("\nBalanced BST");
		System.out.println("Is this a balanced BST " + mbp.isBalanced(mbp.root));
		

	}
}
