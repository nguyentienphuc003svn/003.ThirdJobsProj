import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;


/*
 * A map of <key: number, value: repeat> implemented over a binary search tree 
 */
public class NumberBSTMap{
	protected BSTNode root; // the root of the binary search tree
	protected HashMap<Integer, Integer> repeatMap = new HashMap<Integer, Integer>(); 

	/*
	 * Constructor
	 */
	public NumberBSTMap(){
		this.root = null;	
	}

	/*
	 * Inserts the specified key and value pair into the Map. 
	 * Returns null if the key was not found, otherwise it returns the old value.
	 */
	protected Integer insert(Integer key){
		Integer value = this.checkRepeat(key);

		if (root == null) 
		{
			root = new BSTNode(null, null, null, key, value);
			return null;
		} 
		else
		{	
			BSTNode node = root.add(String.valueOf(key),String.valueOf(value));			
			if (node != null) return node.repeat;
			else return null;
		}
	}

	public Integer checkRepeat(Integer key)
	{
		if (repeatMap.size() <= 0) 
		{
			repeatMap.put(key, 1);
			return repeatMap.get(key);
		}
		else
		{
			if (repeatMap.containsKey(key))
			{
				repeatMap.replace(key, repeatMap.get(key)+1);
				return repeatMap.get(key);				
			}
			else
			{
				repeatMap.put(key, 1);
				return repeatMap.get(key);
			}
		}
	}

	/*
	 * Gets the node that has the given key. 
	 * Returns null if the key was not found, otherwise it returns the node of that key.
	 */
	protected BSTNode getNode(String key){
		if (root == null) return null;
		else return root.search(key);
	}

	/*
	 * Gets the value associated with the given key. 
	 * Returns null if the key was not found, otherwise it returns the associated value.
	 */
	protected Integer get(String key){
		if (root == null) return null;		
		else 
		{	
			if (root.search(key) != null) return root.search(key).repeat;
			else return null;
		}
	}

	/*
	 * Deletes the node that has the given key. 
	 * Returns null if the key was not found, otherwise it returns the associated value.
	 */
	protected Integer delete(String key){
		if (root == null) 
		{
			return null;
		} 
		else
		{	
			BSTNode node = root.delete(key);			
			if (node != null) return node.repeat;
			else return null;
		}

	}
	
	/*
	 * Search the node that has the given key. 
	 * Returns null if the key was not found, otherwise it returns the associated key and value.
	 */
	protected BSTNode search(String key){
		if (root == null) 
		{
			return null;
		} 
		else
		{	
			BSTNode node = root.search(key);			
			if (node != null) return node;
			else return null;
		}
	}

	/*
	 * Gets the number of nodes in the map. 
	 */
	protected int size(){
		if (this.isEmpty()) return 0;
		else
		{
			if (root == null) return 0;
			else return root.countNode(root);
		}

	}

	/*
	 * Returns true if the map is empty, false otherwise.
	 */
	protected boolean isEmpty(){
		if (root == null) return true;		
		else return false;
	}

	/*
	 * Returns an array of all nodes in the tree ordered in the order of the in-order traversal of the tree.
	 */
	protected BSTNode[] inOrder(){
		int size = 0;		
		if (root == null) return null;		
		else size = root.countNode(root);

		BSTNode.nodeArray = new BSTNode[size];
		BSTNode.index = 0;

		return root.printInOrderRec(root);
	}

	protected void printPreOrderRec(BSTNode currRoot) {
		
//		while (currRoot.getParent() != null)
//		{
//			currRoot = currRoot.getParent(); // To get root Node 
//		}
			
		if (currRoot == null) {
			return;
		}
		
		//System.out.println(currRoot.number + ", " + currRoot.repeat);
		System.out.println("Node number " + currRoot.number + " with repeat times " + currRoot.repeat);
		printPreOrderRec(currRoot.left);
		printPreOrderRec(currRoot.right);
	}

	protected void printPostOrderRec(BSTNode currRoot) { 
//		while (currRoot.getParent() != null)
//		{
//			currRoot = currRoot.getParent(); // To get root Node 
//		}
		
		if (currRoot == null) 
		{ 
			return; 
		} 

		printPostOrderRec(currRoot.left); 
		printPostOrderRec(currRoot.right); 
		//System.out.print(currRoot.number + ", " + currRoot.repeat);
		System.out.println("Node number " + currRoot.number + " with repeat times " + currRoot.repeat);

	}

	protected Integer SumTotal()
	{
		Set<Integer> sumSet = repeatMap.keySet();
		Iterator<Integer> sumIT = sumSet.iterator();

		Integer total = 0;
		while (sumIT.hasNext())
		{
			Integer temp = sumIT.next();
			total = total + (temp*repeatMap.get(temp));
		}

		return total;
	}

	protected boolean isBalanced(BSTNode root)
	{
		if(root==null)
		{
			return true;  //tree is empty
		}
		else
		{
			int lh = root.countNode(root.left);
			int rh = root.countNode(root.right);
			if(lh - rh > 1 || rh - lh > 1){
				return false;
			}
		}
		return true;
	}
	
}
